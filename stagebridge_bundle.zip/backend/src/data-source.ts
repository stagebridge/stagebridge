// src/data-source.ts
import 'reflect-metadata';
import { DataSource } from 'typeorm';
import * as path from 'path';

const isProd = process.env.NODE_ENV === 'production';

// 도커 컨테이너 안에서 다른 컨테이너(Postgres)에 접속한다면 host는 보통 서비스명(예: 'postgres').
// 로컬에서 접속한다면 'localhost'를 사용합니다.
const HOST =
  process.env.DB_HOST ||
  (process.env.DOCKER_ENV ? 'postgres' : 'localhost');

export const AppDataSource = new DataSource({
  type: 'postgres',
  host: HOST,
  port: +(process.env.DB_PORT || 5432),
  username: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASS || 'postgres',
  database: process.env.DB_NAME || 'stagebridge',
  // 엔티티/마이그레이션 경로 (ts, js 둘 다 인식)
  entities: [path.join(__dirname, '/**/*.entity{.ts,.js}')],
  migrations: [path.join(__dirname, '/migrations/*{.ts,.js}')],

  synchronize: false, // 마이그레이션을 쓰는 경우 false 권장
  logging: !isProd,
  // 필요 시 SSL:
  // ssl: process.env.DB_SSL === 'true' ? { rejectUnauthorized: false } : false,
});

export default AppDataSource;
